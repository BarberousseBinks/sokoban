FICHIER D'INFOS DU JEU SPEEDYROADIE
-----------------------------------

Les dossiers ClassicMode et PermanSave permettent le bon fonctionnement du jeu.
ClassicMode contient les maps du mode histoire ainsi que les fichiers de sauvegarde.

Pour réinitialiser la sauvegarde du ClassicMode et PermanSave, il faut utiliser la commande

> ant reset

depuis la racine du jeu (endroit où se trouve ce même fichier ainsi que le fichier build.xml)

Le dossier PermanSave permet d'avoir, en temps réel, une sauvegarde des fichiers de la partie en cours.
De ce fait, si vous quittez le jeu en pleine partie, vous pourrez rejouer le niveau à l'endroit où vous étiez.

Le dossier ClassicMode contient toutes les informations du mode Histoire du jeu

Le dossier run est le dossier où la compilation, la javadoc et les tests unitaires ont lieu.

Pour regénérer la javadoc utilisez la commande

> ant javadoc

pour lancer les tests unitaires utilisez la commande

> ant test

Nous vous souhaitons un excellent jeu.